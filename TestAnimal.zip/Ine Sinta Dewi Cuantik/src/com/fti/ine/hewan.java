package com.fti.ine;

public class hewan {

}
