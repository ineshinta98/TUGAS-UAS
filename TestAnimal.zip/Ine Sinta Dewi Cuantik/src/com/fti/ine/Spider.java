package com.fti.ine;
public class Spider extends Animal{
    public Spider(){
        super(8);
    }
    @Override
    public void eat(){
        System.out.println("Spider pemakan segalanya");
    }
}