package com.fti.ine;
public interface Pet {
    public String getName();
    public void setName(String name);
    public void play();
}
